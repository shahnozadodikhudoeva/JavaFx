package LMS;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Locale;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;

import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.KeyEvent;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.stage.WindowEvent;

public class LibrarianController implements Initializable {


    @FXML
    private TableView<ModelTable> table;

    @FXML
    private TableColumn<ModelTable, String> col_id;

    @FXML
    private TableColumn<ModelTable, String> col_name;

    @FXML
    private TableColumn<ModelTable, String> col_author;

    @FXML
    private TableColumn<ModelTable, String> col_year;

    @FXML
    private TableColumn<ModelTable, String> col_status;
    @FXML
    private javafx.scene.control.Button closeButton;

    ObservableList<ModelTable> observableList = FXCollections.observableArrayList();

    //    Add PopUp
    @FXML
    private TextField idTxt;

    @FXML
    private TextField nameTxt;

    @FXML
    private TextField authorTxt;

    @FXML
    private TextField yearTxt;

    @FXML
    private TextField statusTxt;

    @FXML
    private TextField idTxtUpdate;

    @FXML
    private TextField nameTxtUpdate;

    @FXML
    private TextField authorTxtUpdate;

    @FXML
    private TextField yearTxtUpdate;

    @FXML
    private TextField statusTxtUpdate;

    @FXML
    private TextField searchTxt;

    public static int idbooks;

    //    Add function
    @FXML
    void refreshTable() {
        observableList.clear();
        try {
            Connection con = DBConnector.getConnection();
            ResultSet resultSet = con.createStatement().executeQuery("select * from books");
            while (resultSet.next()) {
                observableList.add(new ModelTable(resultSet.getInt("idbooks"), resultSet.getString("id"), resultSet.getString("name"),
                        resultSet.getString("author"), resultSet.getString("year"), resultSet.getString("status")));
            }

        } catch (SQLException throwable) {
            Logger.getLogger(LibrarianController.class.getName()).log(Level.SEVERE, null, throwable);
        }


    }

    @FXML
    void add(ActionEvent event) {
        try {
            Parent parent = FXMLLoader.load(getClass().getResource("assets/addPage.fxml"));
            Scene scene = new Scene(parent);
            Stage stage = new Stage();
            stage.setScene(scene);
            stage.setOnCloseRequest(new EventHandler<WindowEvent>() {
                @Override
                public void handle(WindowEvent windowEvent) {
                    refreshTable();
                    loadData();
                }
            });
            stage.fireEvent(new WindowEvent(stage, WindowEvent.WINDOW_CLOSE_REQUEST));
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.show();
        } catch (IOException ex) {
            Logger.getLogger(LibrarianController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @FXML
    void addBtn(ActionEvent event) {
        String id = idTxt.getText();
        String name = nameTxt.getText();
        String author = authorTxt.getText();
        String year = yearTxt.getText();
        String status = statusTxt.getText();

        if (name.isEmpty() || id.isEmpty() || author.isEmpty() || year.isEmpty() || status.isEmpty()) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setHeaderText(null);
            alert.setContentText("Please fill all fields!!!");
            alert.showAndWait();
        } else {
            try {
                Connection con = DBConnector.getConnection();
                String query = "insert into books (`id`, `name`, `author`, `year`, `status`) values (?,?,?,?,?)";
                PreparedStatement preparedStatement = con.prepareStatement(query);
                preparedStatement.setString(1, id);
                preparedStatement.setString(2, name);
                preparedStatement.setString(3, author);
                preparedStatement.setString(4, year);
                preparedStatement.setString(5, status);
                preparedStatement.execute();
                cancelBtn(event);
            } catch (Exception e) {
                System.out.println(e);

            }
            refreshTable();
        }

    }

    @FXML
    void cancelBtn(ActionEvent event) {
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.close();
        stage.fireEvent(new WindowEvent(stage, WindowEvent.WINDOW_CLOSE_REQUEST));
        refreshTable();
        loadData();

    }


    @FXML
    void delete(ActionEvent event) {
        try {
            Connection con = DBConnector.getConnection();
            ModelTable book = table.getSelectionModel().getSelectedItem();
            String query = "delete from books where id =" + book.getId();
            PreparedStatement preparedStatement = con.prepareStatement(query);
            preparedStatement.execute();
            preparedStatement.close();
            refreshTable();

        } catch (SQLException throwable) {
            Logger.getLogger(LibrarianController.class.getName()).log(Level.SEVERE, null, throwable);
        }
    }

    @FXML
    void update(ActionEvent event) {
        try {
            ModelTable book = table.getSelectionModel().getSelectedItem();
            idbooks = book.getIdbooks();
            Parent parent = FXMLLoader.load(getClass().getResource("assets/updatePage.fxml"));
            idTxtUpdate = (TextField) parent.lookup("#idTxtUpdate");
            idTxtUpdate.setText(book.getId());
            nameTxtUpdate = (TextField) parent.lookup("#nameTxtUpdate");
            nameTxtUpdate.setText(book.getName());
            authorTxtUpdate = (TextField) parent.lookup("#authorTxtUpdate");
            authorTxtUpdate.setText(book.getAuthor());
            yearTxtUpdate = (TextField) parent.lookup("#yearTxtUpdate");
            yearTxtUpdate.setText(book.getYear());
            statusTxtUpdate = (TextField) parent.lookup("#statusTxtUpdate");
            statusTxtUpdate.setText(book.getStatus());
            Scene scene = new Scene(parent);
            Stage stage = new Stage();
            stage.setScene(scene);
            stage.setOnCloseRequest(new EventHandler<WindowEvent>() {
                @Override
                public void handle(WindowEvent windowEvent) {
                    refreshTable();
                    loadData();
                }
            });
            stage.fireEvent(new WindowEvent(stage, WindowEvent.WINDOW_CLOSE_REQUEST));
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.show();
        } catch (IOException ex) {
            Logger.getLogger(LibrarianController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    void loadData() {
        refreshTable();
        try {
            Connection con = DBConnector.getConnection();
            refreshTable();
            col_id.setCellValueFactory(new PropertyValueFactory<>("id"));
            col_name.setCellValueFactory(new PropertyValueFactory<>("name"));
            col_author.setCellValueFactory(new PropertyValueFactory<>("author"));
            col_year.setCellValueFactory(new PropertyValueFactory<>("year"));
            col_status.setCellValueFactory(new PropertyValueFactory<>("status"));
            table.setItems(observableList);
        } catch (Exception e) {

        }
    }
    void search() {
        FilteredList<ModelTable> filteredList = new FilteredList<>(observableList, b -> true);
        searchTxt.textProperty().addListener((observable, oldValue, newValue) -> {
            filteredList.setPredicate(book -> {
                if (newValue == null || newValue.isEmpty()) {
                    return true;
                }

                String lowerCaseFilter = newValue.toLowerCase();
                if (book.getName().toLowerCase().indexOf(lowerCaseFilter) != -1) {
                    return true;
                } else if (book.getAuthor().toLowerCase().indexOf(lowerCaseFilter) != -1) {
                    return true;
                } else {
                    return false;
                }
            });
        });
        SortedList<ModelTable> sortedList = new SortedList<>(filteredList);
        sortedList.comparatorProperty().bind(table.comparatorProperty());
        table.setItems(sortedList);


    }


    public void updateBtn(ActionEvent event) {
        String id = idTxtUpdate.getText();
        String name = nameTxtUpdate.getText();
        String author = authorTxtUpdate.getText();
        String year = yearTxtUpdate.getText();
        String status = statusTxtUpdate.getText();

        if (name.isEmpty() || id.isEmpty() || author.isEmpty() || year.isEmpty() || status.isEmpty()) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setHeaderText(null);
            alert.setContentText("Please fill all fields!!!");
            alert.showAndWait();
        } else {
            try {
                Connection con = DBConnector.getConnection();
                String query = "update `books` set"
                        + "`id` = ?,"
                        + "`name` = ?,"
                        + "`author` = ?,"
                        + "`year` = ?,"
                        + "`status` = ? where idbooks = " + idbooks;
                PreparedStatement preparedStatement = con.prepareStatement(query);
                preparedStatement.setString(1, id);
                preparedStatement.setString(2, name);
                preparedStatement.setString(3, author);
                preparedStatement.setString(4, year);
                preparedStatement.setString(5, status);
                preparedStatement.execute();
                cancelBtn(event);
            } catch (Exception e) {
                System.out.println(e);

            }
            refreshTable();
        }
    }

    @FXML
    void homePage(ActionEvent event) {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader();
            fxmlLoader.setLocation(getClass().getResource("assets/index.fxml"));
            Scene scene = new Scene(fxmlLoader.load(), 630, 400);
            Stage stage = new Stage();
            stage.setScene(scene);
            stage.show();
            ((Node) (event.getSource())).getScene().getWindow().hide();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        refreshTable();
        loadData();
        try{
            search();
        }
        catch (Exception e){

        }



    }


}
