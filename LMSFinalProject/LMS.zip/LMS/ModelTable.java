package LMS;

public class ModelTable {
    int idbooks;
    String id, name, year, author, status;

    public int getIdbooks() {
        return idbooks;
    }

    public void setIdbooks(int idbooks) {
        this.idbooks = idbooks;
    }

    public ModelTable(int idbooks, String id, String name, String author, String year, String status) {
        this.idbooks=idbooks;
        this.id = id;
        this.name = name;
        this.author = author;
        this.year = year;
        this.status = status;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getAuthor() {
        return author;
    }

    public String getYear() {
        return year;
    }

    public String getStatus() {
        return status;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public void setYear(String  year) {
        this.year = year;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
